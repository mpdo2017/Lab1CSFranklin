/**
 * Models a Snake Oil gas station.
 * 
 * @author Doyt Perry/<insert your name here>.
 * @version Winter 2019.
 */
public class Station
{
    // instance variables 
    private String description;
    private Location stationLocation;
    private int fuelType;
    private double pricePerGallon;


    //constants
    
    /**
     * Factor used in calculating conversion to price per GGE.
     */    
    public static final double FACTOR1 = 115400;
    /**
     * First coefficient used in calculating conversion to price per GGE.
     */    
    public static final double COEFF1 = 756.7;
    /**
     * Second coefficient used in calculating conversion to price per GGE.
     */    
    public static final double COEFF2 = 1154;
    
    /**
     * First constructor for objects of class Station.
     */
    public Station()
    {
        // initialize all instance fields to default values per requirements
    }
    
    /**
     * Second constructor for objects of class Station.
     * 
     * @param  inDescription    String  description of station.
     * @param  inLatitude       double  distance in degrees from equator.
     * @param  inLongitude      double  distance in degrees from 
     *                                  prime meridian.
     * @param  inFuelType       int     fuel type
     * @param  inPrice          double  price per gallon.
     */
    public  Station(String inDescription, double inLatitude, double inLongitude, 
                    int inFuelType, double inPrice)
    {
        // initialize instance variables
        // using values passed in as parameters
        // replace this comment with your code
    }
    
    /**
     * Returns the latitude of the station location.
     * 
     * @return double  distance from equator in degrees.
     */
    public double getLatitude()
    {
        return this.stationLocation.getLatitude();
    }
 
    /**
     * Returns the longitude of the station location.
     * 
     * @return double  distance from prime meridian in degrees.
     */
    public double getLongitude()
    {
        // replace this comment & return statement with your code 
        return -1.0;
    }
    
    /**
     * Returns the description of this station.
     *
     * @return  String  station description.
     */
    public String getDescription()
    {
        // replace this comment & return statement with your code 
        return "OOPS";
    }
       
    /**
     * Updates the description of this station.
     * 
     * @param  newDescription    String  station description.
     */
    public void setDescription(String newDescription)
    {
        // replace this comment your code 
    }
    
    /**
     * Returns the price per gallon of fuel at this station.
     *
     * @return  double  price per gallon of fuel.
     */
    public double getPricePerGallon()
    {
        // replace this comment & return statement with your code 
        return -1.0;
    }
    
    /**
     * Updates the price per gallon of fuel at this station.
     * 
     * @param  newPrice  double   new price per gallon of fuel.
     */
    public void setPricePerGallon(double newPrice)
    {
        // replace this comment your code 
    }
    
    /**
     * Returns the fuel type at this station.
     *
     * @return  int  fuel type at this station.
     */
    public int getFuelType()
    {
        // REPLACE this comment & return statement with your code 
        return -1;
    }

    /**
     * Updates the fuel type of this station.
     * 
     * @param  newFuelType  int   new fuel type.
     */
    public void setFuelType(int newFuelType)
    {
        // replace this comment your code 
    }


    /**
     * Calculates price per GGE 
     *    (gasoline gallon equivalent) of fuel at this station.
     * 
     * @return double  price per gge.
     */
    public double calcPricePerGGE()
    {
        // First create a local variable whose value can be used to calculate
        // convert to price per GGE 
        // REPLACE this comment with your code 
        
        // then use the result to return the price per GGE
        // REPLACE this comment & return statement with your code 
        return -1.0;
    }
    
    /**
     * Calculates approximate distance between the input location
     *    and that of this station.
     *    
     *    HINT: Use the distance calculation of the Location class
     * 
     * @param  targLatitude  latitude of target location.
     * @param  targLongitude longitude of target location.
     * @return double  distance in miles.
     */
    public double calcDistance(double targLatitude, double targLongitude)
    {
        // First create a local variable holding a reference to an instance
        // of Location created from the target latitude and longitude
        // REPLACE this comment with your code 
        
        // Use the result as parameter in a call of a method
        // of the Location class for calculating distance between locations
        // REPLACE this comment & return statement with your code 
        return -1.0;
    }

    /**
     * Returns Station information in specifed format.
     * 
     * <pre>Format of the string should be
     *      description [latitude, longitude] price: $price
     * Example: Cobra Gas [39.95, -82.1] price: $2.13 for type 85 fuel</pre>
     *   
     * @return String  formatted with Station info
     */
    public String toString()
    {
        return this.description +
               " " + this.stationLocation +
                " price: $" + this.pricePerGallon + " for type " +
                this.fuelType + " fuel";
    }
    
}
