import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * The test class StationTest tests the Station Class.
 *
 * @author Doyt Perry/<insert your name here>.
 * @version Winter 2019.
 */
public class StationTest 
{
    /**
     * Default constructor for test class StationTest.
     */
    public StationTest()
    {
        // not used in this Lab
    }
  
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        // not used in this Lab
    }
  
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
        // not used in this Lab
    }

    /**
     * Test object creation with no-param constructor.
     */
    @Test
    public void testFirstConstructor()
    {
        // Create an instance of Station object
        Station station1 = new Station();
        
        // Test to see if the instance was created      
        assertNotNull(station1);
            
        // Test instance variables are correctly initialized
        // Note - these tests assumes the get methods are correct
        assertEquals("NO DESCRIPTION PROVIDED", station1.getDescription());
        assertEquals(0.0, station1.getPricePerGallon(), 0.01);
        assertEquals(0, station1.getFuelType());  
            
        assertEquals(0.0, station1.getLatitude(), 0.01);  
        assertEquals(0.0, station1.getLongitude(), 0.01);  
    }

  
    /**
     * Test object creation with 5-param constructor.
     */
    @Test
    public void testSecondConstructor()
    {
        // Create an instance of Station object
        // REPLACE this comment with your code
        
        // Test to see if the instance was created         
        // REPLACE this comment with your code
            
        // Test instance variables are correctly initialized
        // Note - these tests assumes the get methods are correct
        // REPLACE this comment with your code              
    }

    
    /**
     * Test update of Station description.
     */
    @Test
    public void testSetDescription()
    {
        // Create an instance of Station object
        Station station1 = new Station("Cobra Gas", 39.95, -82.1, 85, 2.13);
        
        // Call on the setDescription with a new name        
        station1.setDescription("Rattler Ray's");
        
        // Test whether the value was successfully changed        
        assertEquals("Rattler Ray's", station1.getDescription());
    }

    /**
     * Test update of Station price per gallon.
     */
    @Test
    public void testSetPricePerGallon()
    {
        // Create an instance of Station object
        // REPLACE this comment with your code
        
        // Call on the setPricePerGallon with a new price        
        // REPLACE this comment with your code
        
        // Test whether the value was successfully changed        
        // REPLACE this comment with your code
    }
    
    /**
     * Test update of Station price per gallon.
     */
    @Test
    public void testSetFuelType()
    {
        // Create an instance of Station object
        Station station1 = new Station("Cobra Gas", 39.95, -82.1, 85, 2.13);
        
        // Call on the setFuelType with a new type        
        station1.setFuelType(15);
        
        // Test whether the value was successfully changed        
        assertEquals(15, station1.getFuelType());
    }
    
 
    /**
     * Test calculation of GGE.
     */
    @Test
    public void testCalcPricePerGGE()
    {
        // Create an instance of Station object
        Station station1 = new Station("Cobra Gas", 39.95, -82.1, 85, 2.13);
        
        // Test calculation
        assertEquals(3.01, station1.calcPricePerGGE(), .01);
        
        // Try a DIFFERENT price per gallon AND fuel type
        // REPLACE this comment with your code
    }  
    
    /**
     * Test calculation of distance in miles.
     * 
     *    NOTE: 
     *    This tests a calculation that is improved 
     *    from Lab 1 and should be accurate within 10%
     *  
     */
    @Test
    public void testDistanceInMiles()
    {
        // Create an instance of Station object 
        Station station1 = new Station("Cobra Gas", 38.95, -83.1, 85, 2.13);
        
        // test for (0.0, 0.0)
        assertEquals(0.0, station1.calcDistance(0.0, 0.0), .01);

        // test for Cleveland. OH
        assertEquals(0.0, station1.calcDistance(41.5, -81.6),  .01);
        
        // test with Toledo, OH
        assertEquals(0.0, station1.calcDistance(41.65, -83.55), .01);

        // test Atlanga GA
        assertEquals(0.0, station1.calcDistance(33.75, -84.38), .01);

        // test with Perth, AUSTRALIA
        assertEquals(0.0, station1.calcDistance(-31.95, 115.87), .01);
            
        // test with Buenos Aires, BRAZIL
        assertEquals(0.0, station1.calcDistance(-34.6, -58.35), .01);
    }
    
    

    
    /**
     * Test the toString method.
     * 
     * <pre>Format of the string should be
     *      description [latitude, longitude] price: $price
     * Example: Cobra Gas [39.95, -82.1] price: $2.13 for type 85 fuel</pre>
     * 
     */
    @Test
    public void testToString()
    {
        // Create an instance of Station object 
        Station station1 = new Station("Cobra Gas", 39.95, -82.1, 85, 2.13);
        
        // obtain expected attributes of the Station
        double price = station1.getPricePerGallon();
        double latitude = station1.getLatitude();
        double longitude = station1.getLongitude();
        int type = station1.getFuelType();
        
        // obtain the result string
        String result = station1.toString();

        // check for expected attributes, properly formatted
        // check the result contains the expected description
        assertTrue(result.contains("Cobra Gas "));
        //check the result contains the expected location
        assertTrue(result.contains("[" + latitude + ", " + longitude + "]") );
        //check the result contains the expected price
        assertTrue(result.contains("price: $" + price) );  
        //check the result contains the expected fuel type
        assertTrue(result.contains("type " + type + " fuel") );  
    }
    
}






